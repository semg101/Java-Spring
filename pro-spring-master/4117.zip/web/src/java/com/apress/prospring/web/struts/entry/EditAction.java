/*
 * Created on 14-Nov-2004
 */
package com.apress.prospring.web.struts.entry;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.web.bind.RequestUtils;

import com.apress.prospring.domain.Attachment;
import com.apress.prospring.domain.Entry;
import com.apress.prospring.web.security.SessionSecurityManager;
import com.apress.prospring.web.struts.AbstractBlogManagerAction;


/**
 * @author janm
 */
public class EditAction extends AbstractBlogManagerAction {

	/* (non-Javadoc)
	 * @see com.apress.prospring.web.struts.AbstractBlogManagerAction#executeInternal(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected ActionForward executeInternal(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String forward;
		Entry entry;
		EditEntryForm entryForm = (EditEntryForm)form;
		if (request.getParameter("submit") == null) {
			// we need to load the entry
			int entryId = RequestUtils.getRequiredIntParameter(request, "entryId");
			entry = getBlogManager().getEntry(entryId);
			BeanUtils.copyProperties(entryForm, entry);
			entryForm.setPostDateTime(entry.getPostDate().getTime());
			forward = "edit";
		} else {
			// we are saving the entry
			entry = new Entry();
			BeanUtils.copyProperties(entry, entryForm);
			entry.setPostDate(new Date(entryForm.getPostDateTime()));
			getBlogManager().saveEntry(entry, SessionSecurityManager.getUser(request));

			if (entryForm.getAttachment() != null) {
				Attachment attachment = new Attachment();
				attachment.setContentType("");
				attachment.setFileData(entryForm.getAttachment().getFileData());
				attachment.setFileName("attachment.txt");
				getBlogManager().attachToEntry(attachment, entry.getEntryId());
			}
			
			forward = "posted";
		}
		return mapping.findForward(forward);
	}

}
