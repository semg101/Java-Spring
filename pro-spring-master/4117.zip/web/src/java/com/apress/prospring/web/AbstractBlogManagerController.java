/*
 * Created on 11-Aug-2004
 */
package com.apress.prospring.web;

import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.web.servlet.mvc.Controller;

import com.apress.prospring.business.AuditService;
import com.apress.prospring.business.BlogManager;

/**
 * @author janm
 */
public abstract class AbstractBlogManagerController implements Controller, InitializingBean {

	private BlogManager blogManager;

	private AuditService auditService;

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public final void afterPropertiesSet() throws Exception {
		if (blogManager == null) throw new BeanCreationException("Must set blogManager on indexController");
	}

	/**
	 * Gets the blogManager
	 * 
	 * @return Returns the blogManager.
	 */
	protected final BlogManager getBlogManager() {
		return blogManager;
	}

	protected final AuditService getAuditService() {
		return auditService;
	}

	/**
	 * Sets the blogManager
	 * 
	 * @param blogManager The blogManager to set.
	 */
	public final void setBlogManager(BlogManager blogManager) {
		this.blogManager = blogManager;
	}

	public final void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}
}