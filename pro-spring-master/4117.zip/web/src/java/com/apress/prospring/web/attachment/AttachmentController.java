/*
 * Created on 08-Nov-2004
 */
package com.apress.prospring.web.attachment;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.RequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.apress.prospring.business.BlogManager;
import com.apress.prospring.domain.Attachment;

/**
 * @author janm
 */
public class AttachmentController extends MultiActionController {

	private BlogManager blogManager;

	public ModelAndView handleDownload(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Attachment attachment = blogManager.getAttachment(RequestUtils.getRequiredIntParameter(request, "attachmentId"));

		response.setContentType(attachment.getContentType());
		response.addHeader("Content-disposition", "attachment; filename=" + attachment.getFileName());
		response.getOutputStream().write(attachment.getFileData());

		return null;
	}

	/**
	 * @param blogManager The blogManager to set.
	 */
	public void setBlogManager(BlogManager blogManager) {
		this.blogManager = blogManager;
	}
}
