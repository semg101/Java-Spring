/*
 * Created on 14-Nov-2004
 */
package com.apress.prospring.web.struts.entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

/**
 * @author janm
 */
public class EditEntryForm extends ActionForm {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 2496667806869631383L;

	private int entryId;
	private long postDateTime;
	private String subject;
	private String body;
	private FormFile attachment;

	/* (non-Javadoc)
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
		// perform validation
		return super.validate(mapping, request);
	}

	/**
	 * @return Returns the attachment.
	 */
	public FormFile getAttachment() {
		return attachment;
	}

	/**
	 * @param attachment The attachment to set.
	 */
	public void setAttachment(FormFile attachment) {
		this.attachment = attachment;
	}

	/**
	 * @return Returns the body.
	 */
	public String getBody() {
		return body;
	}

	/**
	 * @param body The body to set.
	 */
	public void setBody(String body) {
		this.body = body;
	}

	/**
	 * @return Returns the subject.
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * @param subject The subject to set.
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}

	/**
	 * @return Returns the entryId.
	 */
	public int getEntryId() {
		return entryId;
	}

	/**
	 * @param entryId The entryId to set.
	 */
	public void setEntryId(int entryId) {
		this.entryId = entryId;
	}

	/**
	 * @return Returns the postDateTime.
	 */
	public long getPostDateTime() {
		return postDateTime;
	}

	/**
	 * @param postDateTime The postDateTime to set.
	 */
	public void setPostDateTime(long postDateTime) {
		this.postDateTime = postDateTime;
	}
}
