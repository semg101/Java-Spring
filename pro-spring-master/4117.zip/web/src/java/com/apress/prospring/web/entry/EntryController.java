/*
 * Created on 10-Aug-2004
 */
package com.apress.prospring.web.entry;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.RequestUtils;
import org.springframework.web.servlet.ModelAndView;

import com.apress.prospring.domain.Entry;
import com.apress.prospring.web.AbstractBlogManagerMultiactionController;
import com.apress.prospring.web.security.SessionSecurityManager;

/**
 * Handles Entry view/delete requests
 * 
 * @author janm
 */
public class EntryController extends AbstractBlogManagerMultiactionController {

	/**
	 * Handles View
	 */
	public ModelAndView handleView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int entryId = RequestUtils.getRequiredIntParameter(request, "entryId");
		Entry e = getBlogManager().getEntry(entryId);
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("entry", e);
		return new ModelAndView("entry-view", model);
	}
	
	/**
	 * Handles delete confirmation and delete
	 */
	public ModelAndView handleDelete(HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean confirm = RequestUtils.getIntParameter(request, "confirm", 0) == 1;
		int entryId = RequestUtils.getRequiredIntParameter(request, "entryId");
		if (confirm) {
			getBlogManager().deleteEntry(entryId, SessionSecurityManager.getUser(request));
			return new ModelAndView("entry-deleted");
		} else {
			Map<String, Object> model = new HashMap<String, Object>();
			model.put("entry", getBlogManager().getEntry(entryId));
			return new ModelAndView("entry-delete", model);
		}
	}
}