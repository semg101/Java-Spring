/*
 * Created on 08-Nov-2004
 */
package com.apress.prospring.web.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.apress.prospring.business.BlogManager;
import com.apress.prospring.domain.User;

/**
 * @author janm
 */
public class LoginController extends AbstractController {

	private BlogManager blogManager;

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.AbstractController#handleRequestInternal(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		if (username != null && password != null) {
			// process login
			User user = blogManager.login(username, password);
			SessionSecurityManager.setUser(request, user);
			return new ModelAndView("index-redirect");
		} else {
			return new ModelAndView("security-login");
		}
	}

	/**
	 * @param blogManager The blogManager to set.
	 */
	public void setBlogManager(BlogManager blogManager) {
		this.blogManager = blogManager;
	}
}
